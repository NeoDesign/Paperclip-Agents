---
name: "NEOs AI Lab"
description: "Human-led governance: Alexander is the board operator. Agents may research, plan, propose and document. Implementation, coding, repository changes, infrastructure changes, hiring, secrets, costs and execution waves require explicit board approval.  Board escalation: If a board decision is required, create a board-assigned issue with the prefix \"Board:\" and block the dependent issue until the board issue is resolved."
schema: "agentcompanies/v1"
slug: "neos-ai-lab"
---

