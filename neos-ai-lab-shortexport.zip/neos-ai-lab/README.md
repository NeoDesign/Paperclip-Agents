# NEOs AI Lab

> Human-led governance: Alexander is the board operator. Agents may research, plan, propose and document. Implementation, coding, repository changes, infrastructure changes, hiring, secrets, costs and execution waves require explicit board approval.  Board escalation: If a board decision is required, create a board-assigned issue with the prefix "Board:" and block the dependent issue until the board issue is resolved.

![Org Chart](images/org-chart.png)

## What's Inside

> This is an [Agent Company](https://agentcompanies.io) package from [Paperclip](https://paperclip.ing)

| Content | Count |
|---------|-------|
| Agents | 9 |
| Projects | 3 |
| Skills | 6 |

### Agents

| Agent | Role | Reports To |
|-------|------|------------|
| AI Daily Companion Code Reviewer | qa | neos-ai-lab-cto |
| AI Daily Companion Documentation Specialist | researcher | neos-ai-lab-cto |
| AI Daily Companion Lead Developer | CEO | neos-ai-lab-cto |
| AI Daily Companion Privacy Officer | security | neos-ai-lab-ceo |
| AI Daily Companion Product Owner | pm | neos-ai-lab-ceo |
| AI Daily Companion QA Engineer | qa | neos-ai-lab-cto |
| AI Daily Companion Repository Cartographer | researcher | neos-ai-lab-cto |
| NEOs AI Lab CEO | CEO | — |
| NEOs AI Lab CTO | CTO | neos-ai-lab-ceo |

### Projects

- **Backlog** — Backlog for the NeuroMate AI Companion



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```
- **Feature Development** — ### Project Governance: AI Daily Companion - Feature Development

This project defines the execution and implementation phase for the AI Daily Companion. The focus is on efficient coding, strict version control via GitHub, and minimizing administrative overhead. Agents must act with high autonomy while strictly adhering to the git branch workflow.

**Agent Behavior & Autonomy Requirements:**

* **No deep sub-task trees:** Keep task structures flat. Agents must not create complex or deeply nested sub-task hierarchies (maximum 1 level of sub-tasks allowed).
* **Single Ownership:** Once an agent is assigned to an issue, they retain ownership until it is ready for review. Do not reassign issues back and forth between agents ("hot potato").
* **Minimize Clarifications:** Agents must make sensible, documented assumptions to keep moving forward instead of pausing to ask repetitive clarifying questions. Document these assumptions in the Pull Request or issue comments.

**Agents MUST:**

* Implement code based on approved backlog items.
* Always create a dedicated branch for each issue before generating files. Use the format: `feature/<issue-number>-<short-description>`.
* Commit and push all generated files, code, and artifacts directly to the remote GitHub branch to ensure the local working tree remains completely clean.
* Open a Pull Request (PR) once the feature is complete.

**Agents MUST NOT, without explicit board approval:**

* Merge code into the main/master branch.
* Modify or change infrastructure.
* Add secrets or credentials to the repository.
* Hire additional agents.
* Create execution waves.

**Required workflow:**

1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.
2. **Branch Creation:** Implementation begins exclusively by creating and checking out the dedicated feature branch (`feature/<issue-number>-...`).
3. **Implementation & Pushing:** Agents write code and immediately push their changes to the remote GitHub repository. The local working directory must not be left dirty.
4. **Autonomy Execution:** Agents complete the issue independently. If minor details are unspecified, agents decide on a best-practice approach and explicitly log their assumptions.
5. **Code Review:** Every code-producing task ends with the creation of a Pull Request. The PR must be assigned to Alexander for review and merge.
6. **Critical Blockers:** Only if a fundamental decision prevents *any* logical progress, agents may create a board-assigned issue with the prefix "Board:" and block the dependent issue until resolved.



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```
- **Onboarding** — Project Governance: AI Daily Companion

This onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.

The first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.

Agents may:

* draft plans
* propose architecture
* suggest milestones
* create issue proposals
* document assumptions
* prepare review artifacts

Agents must not, without explicit board approval:

* start coding
* modify or push to the GitHub repository
* create implementation branches
* create or change infrastructure
* add secrets or credentials
* hire additional agents
* create execution waves

Required workflow:

1. Planning issues may be completed by agents.
2. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.
3. Implementation issues may only be created after the board review has been explicitly approved.
4. Coding may start only after Alexander has approved:
   * the prototype goal
   * the technical architecture
   * the first implementation backlog
   * the code review workflow
5. Every code-producing task requires a separate code review task before merge or acceptance.
6. If a board decision is required, agents must create a board-assigned issue with the prefix "Board:" and block the dependent issue until the board issue is resolved.

Project Governance: AI Daily Companion

This onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.

The first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.

Agents may:

\- draft plans

\- propose architecture

\- suggest milestones

\- create issue proposals

\- document assumptions

\- prepare review artifacts

Agents must not, without explicit board approval:

\- start coding

\- modify or push to the GitHub repository

\- create implementation branches

\- create or change infrastructure

\- add secrets or credentials

\- hire additional agents

\- create execution waves

Required workflow:

1\. Planning issues may be completed by agents.

2\. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.

3\. Implementation issues may only be created after the board review has been explicitly approved.

4\. Coding may start only after Alexander has approved:

&#x20;  \- the prototype goal

&#x20;  \- the technical architecture

&#x20;  \- the first implementation backlog

&#x20;  \- the code review workflow

5\. Every code-producing task requires a separate code review task before merge or acceptance.

6\. If a board decision is required, agents must create a board-assigned issue with the prefix "Board:" and block the dependent issue until the board issue is resolved.

1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```

### Skills

| Skill | Description | Source |
|-------|-------------|--------|
| paperclip-converting-plans-to-tasks | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-converting-plans-to-tasks) |
| paperclip-create-agent | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-create-agent) |
| paperclip-create-plugin | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-create-plugin) |
| paperclip-dev | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-dev) |
| paperclip | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/paperclip) |
| para-memory-files | > | [github](https://github.com/paperclipai/paperclip/tree/master/skills/para-memory-files) |

## Getting Started

```bash
pnpm paperclipai company import this-github-url-or-folder
```

See [Paperclip](https://paperclip.ing) for more information.

---
Exported from [Paperclip](https://paperclip.ing) on 2026-05-26
