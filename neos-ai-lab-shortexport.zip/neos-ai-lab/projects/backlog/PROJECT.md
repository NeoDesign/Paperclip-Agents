---
name: "Backlog"
description: "Backlog for the NeuroMate AI Companion\n\n\n\n```\n## Board Control Block (mandatory in every agent update)\n\n1. Dependency Tree\n- Ready now:\n- Blocked by:\n- Unblocks:\n\n2. Hardware Test Decision\n- Hardware test required: yes/no\n- Why:\n- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)\n- Owner: Alexander(Board) or Agent\n- Exact test runbook link:\n- Evidence required back from owner:\n\n3. Handoff Gate\n- Can this issue be closed without board hardware test? yes/no\n- If no: set status to BLOCKED with unblock owner/action\n```"
---

Backlog for the NeuroMate AI Companion



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```
