---
name: "Feature Development"
description: "### Project Governance: AI Daily Companion - Feature Development\n\nThis project defines the execution and implementation phase for the AI Daily Companion. The focus is on efficient coding, strict version control via GitHub, and minimizing administrative overhead. Agents must act with high autonomy while strictly adhering to the git branch workflow.\n\n**Agent Behavior & Autonomy Requirements:**\n\n* **No deep sub-task trees:** Keep task structures flat. Agents must not create complex or deeply nested sub-task hierarchies (maximum 1 level of sub-tasks allowed).\n* **Single Ownership:** Once an agent is assigned to an issue, they retain ownership until it is ready for review. Do not reassign issues back and forth between agents (\"hot potato\").\n* **Minimize Clarifications:** Agents must make sensible, documented assumptions to keep moving forward instead of pausing to ask repetitive clarifying questions. Document these assumptions in the Pull Request or issue comments.\n\n**Agents MUST:**\n\n* Implement code based on approved backlog items.\n* Always create a dedicated branch for each issue before generating files. Use the format: `feature/<issue-number>-<short-description>`.\n* Commit and push all generated files, code, and artifacts directly to the remote GitHub branch to ensure the local working tree remains completely clean.\n* Open a Pull Request (PR) once the feature is complete.\n\n**Agents MUST NOT, without explicit board approval:**\n\n* Merge code into the main/master branch.\n* Modify or change infrastructure.\n* Add secrets or credentials to the repository.\n* Hire additional agents.\n* Create execution waves.\n\n**Required workflow:**\n\n1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.\n2. **Branch Creation:** Implementation begins exclusively by creating and checking out the dedicated feature branch (`feature/<issue-number>-...`).\n3. **Implementation & Pushing:** Agents write code and immediately push their changes to the remote GitHub repository. The local working directory must not be left dirty.\n4. **Autonomy Execution:** Agents complete the issue independently. If minor details are unspecified, agents decide on a best-practice approach and explicitly log their assumptions.\n5. **Code Review:** Every code-producing task ends with the creation of a Pull Request. The PR must be assigned to Alexander for review and merge.\n6. **Critical Blockers:** Only if a fundamental decision prevents *any* logical progress, agents may create a board-assigned issue with the prefix \"Board:\" and block the dependent issue until resolved.\n\n\n\n```\n## Board Control Block (mandatory in every agent update)\n\n1. Dependency Tree\n- Ready now:\n- Blocked by:\n- Unblocks:\n\n2. Hardware Test Decision\n- Hardware test required: yes/no\n- Why:\n- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)\n- Owner: Alexander(Board) or Agent\n- Exact test runbook link:\n- Evidence required back from owner:\n\n3. Handoff Gate\n- Can this issue be closed without board hardware test? yes/no\n- If no: set status to BLOCKED with unblock owner/action\n```"
---

### Project Governance: AI Daily Companion - Feature Development

This project defines the execution and implementation phase for the AI Daily Companion. The focus is on efficient coding, strict version control via GitHub, and minimizing administrative overhead. Agents must act with high autonomy while strictly adhering to the git branch workflow.

**Agent Behavior & Autonomy Requirements:**

* **No deep sub-task trees:** Keep task structures flat. Agents must not create complex or deeply nested sub-task hierarchies (maximum 1 level of sub-tasks allowed).
* **Single Ownership:** Once an agent is assigned to an issue, they retain ownership until it is ready for review. Do not reassign issues back and forth between agents ("hot potato").
* **Minimize Clarifications:** Agents must make sensible, documented assumptions to keep moving forward instead of pausing to ask repetitive clarifying questions. Document these assumptions in the Pull Request or issue comments.

**Agents MUST:**

* Implement code based on approved backlog items.
* Always create a dedicated branch for each issue before generating files. Use the format: `feature/<issue-number>-<short-description>`.
* Commit and push all generated files, code, and artifacts directly to the remote GitHub branch to ensure the local working tree remains completely clean.
* Open a Pull Request (PR) once the feature is complete.

**Agents MUST NOT, without explicit board approval:**

* Merge code into the main/master branch.
* Modify or change infrastructure.
* Add secrets or credentials to the repository.
* Hire additional agents.
* Create execution waves.

**Required workflow:**

1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.
2. **Branch Creation:** Implementation begins exclusively by creating and checking out the dedicated feature branch (`feature/<issue-number>-...`).
3. **Implementation & Pushing:** Agents write code and immediately push their changes to the remote GitHub repository. The local working directory must not be left dirty.
4. **Autonomy Execution:** Agents complete the issue independently. If minor details are unspecified, agents decide on a best-practice approach and explicitly log their assumptions.
5. **Code Review:** Every code-producing task ends with the creation of a Pull Request. The PR must be assigned to Alexander for review and merge.
6. **Critical Blockers:** Only if a fundamental decision prevents *any* logical progress, agents may create a board-assigned issue with the prefix "Board:" and block the dependent issue until resolved.



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```
