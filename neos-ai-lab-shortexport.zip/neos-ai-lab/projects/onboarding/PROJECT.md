---
name: "Onboarding"
description: "Project Governance: AI Daily Companion\n\nThis onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.\n\nThe first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.\n\nAgents may:\n\n* draft plans\n* propose architecture\n* suggest milestones\n* create issue proposals\n* document assumptions\n* prepare review artifacts\n\nAgents must not, without explicit board approval:\n\n* start coding\n* modify or push to the GitHub repository\n* create implementation branches\n* create or change infrastructure\n* add secrets or credentials\n* hire additional agents\n* create execution waves\n\nRequired workflow:\n\n1. Planning issues may be completed by agents.\n2. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.\n3. Implementation issues may only be created after the board review has been explicitly approved.\n4. Coding may start only after Alexander has approved:\n   * the prototype goal\n   * the technical architecture\n   * the first implementation backlog\n   * the code review workflow\n5. Every code-producing task requires a separate code review task before merge or acceptance.\n6. If a board decision is required, agents must create a board-assigned issue with the prefix \"Board:\" and block the dependent issue until the board issue is resolved.\n\nProject Governance: AI Daily Companion\n\nThis onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.\n\nThe first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.\n\nAgents may:\n\n\\- draft plans\n\n\\- propose architecture\n\n\\- suggest milestones\n\n\\- create issue proposals\n\n\\- document assumptions\n\n\\- prepare review artifacts\n\nAgents must not, without explicit board approval:\n\n\\- start coding\n\n\\- modify or push to the GitHub repository\n\n\\- create implementation branches\n\n\\- create or change infrastructure\n\n\\- add secrets or credentials\n\n\\- hire additional agents\n\n\\- create execution waves\n\nRequired workflow:\n\n1\\. Planning issues may be completed by agents.\n\n2\\. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.\n\n3\\. Implementation issues may only be created after the board review has been explicitly approved.\n\n4\\. Coding may start only after Alexander has approved:\n\n&#x20;  \\- the prototype goal\n\n&#x20;  \\- the technical architecture\n\n&#x20;  \\- the first implementation backlog\n\n&#x20;  \\- the code review workflow\n\n5\\. Every code-producing task requires a separate code review task before merge or acceptance.\n\n6\\. If a board decision is required, agents must create a board-assigned issue with the prefix \"Board:\" and block the dependent issue until the board issue is resolved.\n\n1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.\n\n\n\n```\n## Board Control Block (mandatory in every agent update)\n\n1. Dependency Tree\n- Ready now:\n- Blocked by:\n- Unblocks:\n\n2. Hardware Test Decision\n- Hardware test required: yes/no\n- Why:\n- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)\n- Owner: Alexander(Board) or Agent\n- Exact test runbook link:\n- Evidence required back from owner:\n\n3. Handoff Gate\n- Can this issue be closed without board hardware test? yes/no\n- If no: set status to BLOCKED with unblock owner/action\n```"
---

Project Governance: AI Daily Companion

This onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.

The first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.

Agents may:

* draft plans
* propose architecture
* suggest milestones
* create issue proposals
* document assumptions
* prepare review artifacts

Agents must not, without explicit board approval:

* start coding
* modify or push to the GitHub repository
* create implementation branches
* create or change infrastructure
* add secrets or credentials
* hire additional agents
* create execution waves

Required workflow:

1. Planning issues may be completed by agents.
2. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.
3. Implementation issues may only be created after the board review has been explicitly approved.
4. Coding may start only after Alexander has approved:
   * the prototype goal
   * the technical architecture
   * the first implementation backlog
   * the code review workflow
5. Every code-producing task requires a separate code review task before merge or acceptance.
6. If a board decision is required, agents must create a board-assigned issue with the prefix "Board:" and block the dependent issue until the board issue is resolved.

Project Governance: AI Daily Companion

This onboarding project defines the controlled starting point for the AI Daily Companion. The AI Daily Companion is a human-directed prototype project. Agents may support Alexander by preparing plans, architecture proposals, milestones, backlog items, issue proposals, documentation, assumptions, and review artifacts.

The first approved project outcome is not code, but an Alexander-approved prototype plan and execution backlog.

Agents may:

\- draft plans

\- propose architecture

\- suggest milestones

\- create issue proposals

\- document assumptions

\- prepare review artifacts

Agents must not, without explicit board approval:

\- start coding

\- modify or push to the GitHub repository

\- create implementation branches

\- create or change infrastructure

\- add secrets or credentials

\- hire additional agents

\- create execution waves

Required workflow:

1\. Planning issues may be completed by agents.

2\. Before implementation begins, a Board review issue must be created and assigned to Alexander / Me.

3\. Implementation issues may only be created after the board review has been explicitly approved.

4\. Coding may start only after Alexander has approved:

&#x20;  \- the prototype goal

&#x20;  \- the technical architecture

&#x20;  \- the first implementation backlog

&#x20;  \- the code review workflow

5\. Every code-producing task requires a separate code review task before merge or acceptance.

6\. If a board decision is required, agents must create a board-assigned issue with the prefix "Board:" and block the dependent issue until the board issue is resolved.

1. Before creating a new feature branch, agents MUST fetch and pull the latest changes from the remote `main` branch to ensure their local working tree is up to date.



```
## Board Control Block (mandatory in every agent update)

1. Dependency Tree
- Ready now:
- Blocked by:
- Unblocks:

2. Hardware Test Decision
- Hardware test required: yes/no
- Why:
- Required hardware: (Hailo / RK3588 / Mic / USB disk / none)
- Owner: Alexander(Board) or Agent
- Exact test runbook link:
- Evidence required back from owner:

3. Handoff Gate
- Can this issue be closed without board hardware test? yes/no
- If no: set status to BLOCKED with unblock owner/action
```
